### 課題5

**三目並べの　AWTへの移植**  
MyFrame.java
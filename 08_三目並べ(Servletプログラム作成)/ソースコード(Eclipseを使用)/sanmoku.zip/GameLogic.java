package model;
 
public class GameLogic {

}
